package dev.slickcollections.kiwizin.bedwars.utils;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.ChunkGenerator;

import java.util.Collections;
import java.util.List;
import java.util.Random;

public class VoidChunkGenerator extends ChunkGenerator {
  
  public static final VoidChunkGenerator VOID_CHUNK_GENERATOR = new VoidChunkGenerator();
  
  @Override
  public List<BlockPopulator> getDefaultPopulators(World world) {
    return Collections.emptyList();
  }
  
  @Override
  public ChunkData generateChunkData(World world, Random random, int chunkX, int chunkZ, BiomeGrid biome) {
    ChunkGenerator.ChunkData chunkData = super.createChunkData(world);
    
    for (int x = 0; x < 16; x++) {
      for (int z = 0; z < 16; z++) {
        biome.setBiome(x, z, Biome.PLAINS);
      }
    }
    
    return chunkData;
  }
  
  @Override
  public boolean canSpawn(World world, int x, int z) {
    return true;
  }
  
  @Override
  public Location getFixedSpawnLocation(World world, Random random) {
    return new Location(world, 0, 100, 0);
  }
}
